#include <iostream>
#include <blitz/array.h>
#include <cstdlib>
#include <cmath>

using namespace blitz;

/*
Function to advance set of coupled first-order o.d.e.s by single step
using adaptive fourth-order Runge-Kutta scheme
x ... independent variable
y ... array of dependent variables
h ... step-length
t_err ... actual truncation error per step
d_err ... desired truncation error per step
h_min ... minimum allowable step-length
h_max ... maximum allowable step-length
*/

const double d_err = 2e-7;
const double h_min = 1e-8;
const double h_max = 0.5;
const int maxrept = 8;
const double S = 0.6;

void dervt(double x, Array<double,1> y, Array<double,1> &dydx)
{
	dydx(0) = y(1);
	dydx(1) = y(1) - y(0) * y(0) * y(1) - y(0);
}

void rk4(double &x, Array<double,1> &y, void (*dervt)(double, Array<double, 1>, Array<double,1> &), double h)
{
	int n = y.extent(0);
	Array<double, 1> k1(n), k2(n), k3(n), k4(n), f(n), dydx(n);
	dydx = 0.0, 0.0;

	(*dervt)(x, y, dydx);
	for (int j = 0; j < n; j++)
	{
		k1(j) = dydx(j);
		f(j) = y(j) + k1(j)*h/2.0;
	}

	(*dervt)(x + h/2.0, f, dydx);
	for (int j = 0; j < n; j++)
	{
		k2(j) = dydx(j);
		f(j) = y(j) + k2(j) * h/2.0;
	}

	(*dervt)(x + h / 2.0, f, dydx);
	for (int j = 0; j < n; j++)
	{
		k3(j) = dydx(j);
		f(j) = y(j) + k3(j) * h;
	}

	(*dervt)(x + h, f, dydx);
	for (int j = 0; j < n; j++)
	{
		k4(j) = dydx(j);
	}

	for (int i = 0; i < n; i++)
	{
		y(i) = y(i) + (k1(i) + 2 * k2(i) + 2 * k3(i) + k4(i))*h / 6.0;
	}

	return;
}

void adaptrk4(double& x, Array<double, 1>& y, void (*dervt)(double, Array<double, 1>, Array<double, 1>&), double& h, int& rept, int flag)
{
	int n = y.extent(0);
	Array<double, 1> ys(n), yd(n), error(n);
	static int count = 0;
	double x0, t_err;

	// setting initial value
	x0 = x;
	ys = y;
	// single step
	rk4(x0, ys, dervt, h);

	// setting initial value
	x0 = x;
	yd = y;

	// double step
	rk4(x0, yd, dervt, h/2);
	rk4(x0, yd, dervt, h/2);
	
	// Calculate truncation error
	t_err = 0.;
	double err, err1, err2;
	if (flag == 0)
	{
		// Use absolute truncation error. An absolute error estimate is appropriate to a system of equations in which the amplitudes of the various dependent variables remain bounded
		for (int i = 0; i < n; i++)
		{
			err = fabs(yd(i) - ys(i));
			t_err = (err > t_err) ? err : t_err;
		}
	}
	else if (flag == 1)
	{
		// Use relative truncation error. A relative error estimate is appropriate to a system in which the amplitudes of 
		// the dependent variables blow - up at some point, but the variables always remain the same sign.
		for (int i = 0; i < n; i++)
		{
			err = fabs((yd(i) - ys(i)) / yd(i));
			t_err = (err > t_err) ? err : t_err;
		}
	}
	else
	{
		// Use mixed truncation error. a mixed error estimate�usually the minimum of the absolute and relative errors�is appropriate to a system in which the amplitudes of the
		// dependent variables blow - up at some point, but the signs of the variables oscillate.
		for (int i = 0; i < n; i++)
		{
			err1 = fabs((yd(i) - ys(i)) / yd(i));
			err2 = fabs(yd(i) - ys(i));
			err = (err1 < err2) ? err1 : err2;
			t_err = (err > t_err) ? err : t_err;
		}
	}

	// Prevent small truncation error from rounding to zero
	if (t_err == 0.) t_err = 1.e-15;

	// Calculate new step-length
	double h_est = h * pow(fabs(d_err / t_err), 0.2);

	// Prevent step-length from changing by more than factor S
	if (h_est / h < S)
		h *= S;
	else if (h_est / h > 1. / S)
		h /= S;
	else
		h = h_est;

	// Prevent step-length from exceeding h_max
	h = (fabs(h) > h_max) ? h_max * h / fabs(h) : h;

	// Abort if step-length falls below h_min
	if (fabs(h) < h_min)
	{
		printf("Error - |h| < hmin\n");
		exit(1);
	}
	// If truncation error acceptable take step
	if ((t_err <= d_err) || (rept >= maxrept))
	{
		rept = count;
		count = 0;
		y = ys;
	}
	// If truncation error unacceptable repeat step
	else
	{
		count++;
		adaptrk4(x, y, dervt, h, rept, flag);
	}

	return;
}


int main(void)
{
	Array<double, 1> y(2);
	y = 2.0, 0.0;
	double h = 0.001, x = 0.0;
	int rept = 1, flag = 0;
	short cwidth = 20;

	FILE* fp1, * fp2;
	fp1 = fopen("data1.tmp", "w");
	fp2 = fopen("data2.tmp", "w");

	int i = 0;
	std::cout << std::setw(cwidth) << "No." << std::setw(cwidth) << "x" << std::setw(cwidth) << "y" << std::setw(cwidth) << "yp" << std::setw(cwidth) << "h" << std::endl;
	std::cout << std::setw(cwidth) << i << std::setw(cwidth) << x << std::setw(cwidth) << y(0) << std::setw(cwidth) << y(1) << std::setw(cwidth) << h << std::endl;
	while (x <= 100)
	{
		adaptrk4(x, y, dervt, h, rept, flag);
		x = x + h;

		std::cout << std::setw(cwidth) << i << std::setw(cwidth) << x << std::setw(cwidth) << y(0) << std::setw(cwidth) << y(1) << std::setw(cwidth) << h << std::endl;
		fprintf(fp1, "%lf \t %lf\n", x, y(0));
		fprintf(fp2, "%lf \t %lf\n", x, y(1));
		i++;
	}

	fclose(fp1);
	fclose(fp2);
	
	return 0;
}