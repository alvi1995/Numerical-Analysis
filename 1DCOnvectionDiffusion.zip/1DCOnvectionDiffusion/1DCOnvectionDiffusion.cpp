//|----------------------------------|
//|Md. Mesbahose Salekeen			 |
//|1-D Convection Diffusion Equation |
//|__________________________________|

#include <conio.h>
#include "matplotlibcpp.h"
#include <vector>
#include <iostream>                                  
#include <Eigen/Dense>                               
#include <Eigen/Sparse>                              
#include <Eigen/Core>
#include <cstdlib>

using namespace Eigen;
using namespace std;
namespace plt = matplotlibcpp;

Eigen::SparseMatrix<double> banded(const Eigen::Matrix<double, Dynamic, Dynamic> d, const Eigen::Vector<double, Dynamic> l, int n)
{
	const int Nd = d.cols();
	const int Nl = l.rows();

	if (Nd != Nl)
	{
		cout << "No diagonal entry must match with given matrix columns" << endl;
		exit(-1);
	}
	double sum = 0;
	for (int i = 0; i < Nl; i++)
	{
		sum = sum + abs(l(i));
	}
	SparseMatrix<double> c(n, n);
	typedef Eigen::Triplet<double> T;
	std::vector<T> tripletList;
	tripletList.reserve(n * Nd - sum);

	for (int i = 0; i < Nl; i++)
	{
		double ll = abs(l(i));
		if (l(i) < 0)
		{
			for (int j = ll, k = 0; j < n && k < n - ll; j++, k++)
			{
				tripletList.push_back(T(j, k, d(j, i)));
			}
		}
		else if (l(i) > 0)
		{
			for (int j = 0, k = ll; j < n - ll && k < n; j++, k++)
			{
				tripletList.push_back(T(j, k, d(j, i)));
			}
		}
		else
		{
			for (int j = 0, k = 0; j < n && k < n; j++, k++)
			{
				tripletList.push_back(T(j, k, d(j, i)));
			}
		}
	}
	c.setFromTriplets(tripletList.begin(), tripletList.end());

	return c;
}

int main(void)
{
	int L = 5; // Length
	const int N = 50;
	double L_cell = L / (double)N;
	double U = .1; // velocity
	const double c_p = 1000; //specific heat capacity
	const double k = 100; //thermal conductivity
	const double rho = 1; // density
	double A = 0.1; // Area
	const double S = 1000;// constant source of heat
	double T_A = 100; // Temparature at A
	double T_B = 200; // Temparature at B

	struct cell_param
	{
		double xc; // for centroid
		double xb[2]; // boundary points location of each cell
		double Ab[2]; // boundary area of right and left
		double D[2]; // diffusive flux of heat
		double F[2]; // convective flux of heat 
	}cell[N]{};

	cell[0].xc = L_cell / 2.0;
	cell[0].xb[0] = 0;
	cell[0].xb[1] = L_cell;
	cell[0].Ab[0] = A;
	cell[0].Ab[1] = A;

	for (int i = 1; i < N; i++)
	{
		cell[i].xc = cell[i - 1].xc + L_cell;
		for (int j = 0; j < 2; j++)
		{
			cell[i].Ab[j] = A;
			cell[i].xb[j] = cell[i - 1].xb[j] + L_cell;
		}
	}

	double d;

	d = cell[0].xc - 0;
	cell[0].D[0] = k / d;
	d = cell[1].xc - cell[0].xc;
	cell[0].D[1] = k / d;
	cell[0].F[0] = rho * c_p * A * U;
	cell[0].F[1] = rho * c_p * A * U;

	for (int i = 1; i < N - 1; i++)
	{
		for (int j = 0; j < 2; j++)
		{
			d = cell[i + j].xc - cell[i + j - 1].xc;
			cell[i].D[j] = k / d;
			cell[i].F[j] = rho * c_p * A * U;
		}
	}

	d = (cell[N - 1].xc - cell[N - 2].xc);
	cell[N - 1].D[0] = k / d;
	d = L - cell[N - 1].xc;
	cell[N - 1].D[1] = k / d;
	cell[N - 1].F[0] = rho * c_p * A * U;
	cell[N - 1].F[1] = rho * c_p * A * U;

	Vector<double, N> aL, aP, aR, S_u;

	aL(0) = 0;
	aR(0) = cell[0].D[1] * cell[0].Ab[1] - cell[0].F[1] / 2.0;
	aP(0) = aL(0) + aR(0) + (cell[0].F[1] - cell[0].F[0]) + (cell[0].D[0] * cell[0].Ab[0] + cell[0].F[0]);
	S_u(0) = T_A * (cell[0].D[0] * cell[0].Ab[0] + cell[0].F[0]) + S * A * L_cell;

	for (int i = 1; i < N - 1; i++)
	{
		aL(i) = cell[i].D[0] * cell[i].Ab[0] + cell[i].F[0] / 2.0;
		aR(i) = cell[i].D[1] * cell[i].Ab[1] - cell[i].F[1] / 2.0;
		aP(i) = aL(i) + aR(i) + (cell[i].F[1] - cell[i].F[0]);
		S_u(i) = S * A * L_cell;
	}

	aL(N - 1) = cell[N - 1].D[0] * cell[N - 1].Ab[0] + cell[N - 1].F[0] / 2.0;
	aR(N - 1) = 0;
	aP(N - 1) = aL(N - 1) + aR(N - 1) + (cell[N - 1].F[1] - cell[N - 1].F[0]) + (cell[N - 1].D[1] * cell[N - 1].Ab[1] - cell[N - 1].F[1]);
	S_u(N - 1) = T_B * (cell[N - 1].D[1] * cell[N - 1].Ab[1] - cell[N - 1].F[1]) + S * A * L_cell;

	Matrix<double, N, 3> diag;
	diag << (-1) * aL, aP, (-1)* aR;
	Vector<double, 3> loc;
	loc << -1, 0, 1;

	SparseLU<SparseMatrix<double> > solver;
	//ConjugateGradient<SparseMatrix<double> > solver; // does not work. I guess not preconditioned
	solver.compute(banded(diag, loc, N));

	/*MatrixXd system(N, N + 1);
	system << MatrixXd(banded(diag, loc, N)), S_u;*/
	//cout << system << endl;
	if (solver.info() != Success) {
		cout << "decomposition failed" << endl;
		return -1;
	}
	Vector<double, N> temparature;
	temparature = solver.solve(S_u);

	if (solver.info() != Success)
	{
		cout << "Solving failed" << endl;
		return -1;
	}
	cout << temparature << "\n\n" << endl;

	vector<double> Te(N+2), xp(N+2);

	Te.push_back(T_A);
	xp.push_back(0);

	for (int i = 0; i < N; i++)
	{
		Te.push_back(temparature(i));
		xp.push_back(cell[i].xc);
	}

	Te.push_back(T_B);
	xp.push_back(L);

	plt::figure_size(1200, 700);
	plt::plot(xp, Te, "bl--");
	plt::named_plot("Temperature Distribution", xp, Te);
	plt::xlim(0, 5);
	//plt::ylim(90, 210);
	plt::title("1-D Convection Diffusion Equation");
	plt::legend();
	plt::show();

	return 0;
}

